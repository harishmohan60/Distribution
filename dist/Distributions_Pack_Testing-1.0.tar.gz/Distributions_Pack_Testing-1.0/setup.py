from setuptools import setup

setup(name='Distributions_Pack_Testing',
      version='1.0',
      description='Gaussian Distributions_Pack_Testing',
      packages=['Distributions_Pack_Testing'],
      author='Harish Mohanaselvam',
      author_email='harish.msl@hotmail.com',
      zip_safe=False)
